Redux Equalizer — Mac VST3 v1.0

Requires macOS 26.0 or newer and a stereo VST3 host. Universal arm64/x86_64.

Install
Extract the ZIP and copy the complete ATP Redux Equalizer.vst3 bundle into
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
This one bundle supplies three host entries: ATP Redux Equalizer 2,
ATP Redux Equalizer 4 and ATP Redux Equalizer 6. Replace an existing copy
of this same bundle rather than keeping duplicates.

Variants and controls
The 2-band variant uses bands 1 and 6; the 4-band variant uses 1, 2, 5 and 6;
the 6-band variant uses all six. Each band has independent left and right
Enable, Type, Gain, Frequency and Q parameters. Bands start disabled.

Choose a band with its numbered tab or graph node. Drag graph nodes to change
frequency and gain. Gain, Frequency and Q also have rotary controls. Gain spans
-18 to +18 dB, Frequency approximately 16 to 21357 Hz, and Bell Q 0.26 to 6.50.
Non-Bell types restrict effective Q to approximately 0.71 to 1.41. Available
Type choices depend on the band: inner bands offer Bell or their shelf;
outer bands also offer pass and resonant-shelf responses.

L and R choose the channel being edited. LINK applies relative paired edits
in each control's own scale until a limit is reached; band Enable and Type
are applied identically to both channels. LINK affects editor edits, while
host automation still addresses each left/right parameter independently.

The two output faders span -24 to +12 dB. Output meters and peak holds
observe processed audio. Clicking the output peak/meter area requests a
peak-hold reset, applied as audio is processed. TRIM applies a shared
peak-based correction to both output faders, within their ranges, and
requests a peak reset. With no recorded peak, TRIM uses a +12 dB correction.

RTA toggles the local spectrum display of the averaged stereo output; it
does not change the audio. Band selection, L/R, LINK and RTA are local editor
settings. Tab moves focus among the three knobs and the two output faders;
arrow keys adjust the focused control. Host bypass remains available in
the audio host.

Processing
Stereo 32-bit and 64-bit floating-point processing with zero reported latency.
The 2/4/6-band variants retain their original parameter identities and saved
project compatibility.

License
Full project and applicable third-party notices are included in LICENSES/.
