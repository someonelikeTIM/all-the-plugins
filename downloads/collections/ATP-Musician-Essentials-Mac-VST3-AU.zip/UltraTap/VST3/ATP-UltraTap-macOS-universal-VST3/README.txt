UltraTap — Mac VST3 v1.0

Requires macOS 12.0 or newer and a stereo VST3 host. Universal arm64/x86_64.
Inspired by Waves SuperTap. Independent implementation, not affiliated with Waves.

Install
Extract the ZIP and copy ATP UltraTap.vst3 into ~/Library/Audio/Plug-Ins/VST3/,
then reopen and rescan your host. One bundle supplies ATP UltraTap 2 and 6.
For the compatible Echo Parcel rename, move the old bundle outside the host's
scan folders first. IDs and saved state remain compatible; factory1.0.0.

Controls
Tempo BPM/MS set tempo or its period; Host Tempo follows valid host tempo.
Direct enables, levels and rotates the undelayed signal. Each tap has enable,
gain, rotation, delay and filter controls. The pan graph edits gain/rotation.
Snap, Grid and Units control timing. Feedback mode selects the normalized tap
mix or the separate feedback delay. Feedback EQ filters the return. Shared
modulation varies delay with rate in Hz or cycles per beat and depth in ms.
Output sets level; meters display processed audio. Host bypass is available.
Tap Pad records tempo taps in Tempo mode or places taps in Pattern mode.
High feedback can sustain echoes; leave room after source audio for the tail.

License
Full project and applicable third-party notices are included in LICENSES/.
