Redux Compressor — Mac VST3 v1.0

Requires macOS 26.0 or newer and a stereo VST3 host. Universal arm64/x86_64.

Install
Extract the ZIP and copy the complete ATP Redux Compressor.vst3 bundle to
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
Replace an existing copy of this same plugin rather than keeping duplicates.

Controls
Threshold: Sets the compression threshold from −60 to 0 dB.
Ratio: Sets the compression or expansion ratio from 0.50 to 50.00; 1.00 is neutral.
Gain: Sets processed-path gain from −30 to +30 dB.
Attack and Release: Set attack from 0.5 to 500 ms and release from 5 to 5000 ms.
ARC / Manual: Chooses automatic release behavior or manual release time.
Electro / Opto: Selects the release behavior.
Warm / Smooth: Selects detector response.
Mix: Blends the delayed dry and processed signals from 0% to 100%.
Trim: Adjusts the mixed output from −18 to +18 dB.
Input, Output, reduction display and limiter light: Display main signal peak levels, signed gain change and limiter activity from the audio engine.
External sidechain: The audio host can enable and route an optional stereo sidechain input; it is inactive by default.

Defaults: Threshold 0 dB, Gain 0 dB, Attack approximately 16 ms, Ratio 1.00,
ARC, Electro, Warm, Release approximately 160 ms, Mix 100%, Trim 0 dB.
Drag faders and sliders. Drag Mix and Trim vertically to adjust the knobs.
Click mode buttons. Tab moves focus; arrow keys adjust the focused control.
Host bypass remains available through the audio host.

Processing
Stereo 32-bit and 64-bit floating-point processing. The optional stereo
sidechain is routed by the host. Lookahead latency is 64, 128 or 256 samples
according to sample rate; the reported tail equals that delay. Existing
parameter identifiers and saved projects retain their original behavior.

License
Full project and applicable third-party notices are included in LICENSES/.
