Double Trouble — Mac Audio Unit v1.0

Requires macOS 12.0 or newer and a stereo Audio Unit host. Universal arm64/x86_64.

Inspired by Waves Doubler. Independent implementation; not affiliated with Waves.

Install
Extract the ZIP and copy the complete ATP Double Trouble.component bundle into
~/Library/Audio/Plug-Ins/Components/, then reopen and rescan your audio host.
One bundle supplies ATP Double Trouble 2 and ATP Double Trouble 4.

Controls
The two variants provide two or four independent voices. Each voice has
Enable, Gain, Pan, Delay, Feedback, Octave, Detune, Depth and Rate controls.
Direct, tone shelves, input source selectors, range switches, Reset and the
output fader provide the shared controls. Graphs edit the corresponding
pan/gain, delay/detune and tone values. Host bypass remains available.
Tab selects controls; arrow keys adjust the focused control. Output meters
show processed stereo audio. The original parameter IDs and saved state
remain compatible; internal factory version is 1.0.0.

License
Full project and applicable third-party notices are included in LICENSES/.

The conventional AU wrapper supports stereo 32-bit floating-point processing.
It uses Apple AudioUnitSDK 1.3.0; its complete Apache 2.0 license is included
in LICENSES/Apple-AudioUnitSDK-Apache-2.0.txt.
