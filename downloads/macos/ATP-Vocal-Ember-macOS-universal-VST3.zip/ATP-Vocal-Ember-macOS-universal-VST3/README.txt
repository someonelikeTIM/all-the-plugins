Vocal Ember — Mac VST3 v1.1

Install
Extract the ZIP and copy the complete ATP Vocal Ember.vst3 bundle into
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
Replace an existing copy of this same plugin rather than keeping duplicates.

Controls
Mode selects Analog, Retro, Tape, Tube, Warm, Decimate or Distort. Amount
controls saturation intensity, and Wet Mix blends it with the dry signal.
The high-shelf node adjusts Frequency and Gain; Q adjusts its shape.
Input and Output use gain faders. Pan and Width use horizontal sliders.
The two signal meters observe input and output from actual processed blocks.

Module Bypass bypasses the saturation module while retaining the wrapper's
other wet-path controls. Global Bypass compares against raw input. Match
level-matches that raw global-bypass path against the processed signal;
with Match active, global bypass is not an unscaled unity-gain comparison.
Both bypass controls and Match are original functional controls.

Drag the knobs, faders, sliders or shelf node to adjust. Wheel over the graph
adjusts Shelf Q. Mode and switches respond to clicks. Amount and shelf Q also have numeric
readouts. The seven-mode default is Tape. Width defaults to its centered
0 display (normalized 0.5); its actual stereo processing law is unchanged.

Processing and compatibility
32-bit and 64-bit floating-point mono and stereo, with zero reported latency.
The thirteen parameter identifiers and existing projects remain compatible.
State remains the 124-byte VEM1/version1 format with thirteen normalized
parameters and its checksum. Public v1.1 does not introduce a new state format.

License
Full project and applicable third-party notices are included in LICENSES/.
