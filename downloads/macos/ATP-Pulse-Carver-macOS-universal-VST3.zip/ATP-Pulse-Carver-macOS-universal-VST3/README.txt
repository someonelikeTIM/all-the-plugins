Pulse Carver — Mac VST3 v1.1

Install
Extract the ZIP and copy the complete ATP Pulse Carver.vst3 bundle into
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
Replace an existing copy of this same plugin rather than keeping duplicate copies.

Main controls
Depth sets modulation amount. Groove and Feel alter rhythmic placement, and
Accent adjusts the pattern's emphasis. Input and Output adjust their gain trims.
Sync follows the host clock; turn it off to use the Rate knob or repeated Tap
Tempo presses. The Shape and Rhythm selectors choose presets or saved custom
patterns. ANA switches Analog/Digital operation; the color selector chooses
Clean, Crunch, Fat, Shred, Squash, Pump, Dirt or Op-Amp. Selecting Op-Amp chooses
Digital; selecting another style chooses Analog.

Expanded controls
EDIT/CLOSE opens or closes the lower panel. Threshold, Attack, Release and
ENV/GATE control the detector. Rate Mod, Depth Mod and Width adjust its influence.
The shape graph supports adding and dragging internal nodes, or right-clicking
to remove them. Shape endpoints remain protected. Smoothing and the curvature
buttons shape transitions. Click a rhythm event to remove it or click a free
position to add an event; Bars, Beats/Bar, Edit Bar and Grid define the pattern.
Shape/rhythm presets, custom graphs and editor options are saved in plugin state.

Drag or wheel rotary controls to adjust them; double-click resets a default.
The host's Bypass parameter remains available; there is no extra editor bypass.

Processing
32-bit floating-point mono and stereo at 44.1, 48, 88.2, 96, 176.4 and 192 kHz.
Reported latency: 45 samples at 44.1/48 kHz, 64 at 88.2/96 kHz, and 128 at
176.4/192 kHz. Parameter IDs and the existing PLS1/v2 variable-length saved-state
format remain unchanged. Public v1.1 is a release label, not a new state version.

License
Full project and applicable third-party notices are included in LICENSES/.
