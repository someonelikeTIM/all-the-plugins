Needle Press — v1.1
Mac VST3

INSTALL
Extract this ZIP. Copy the complete ATP Needle Press.vst3 bundle into ~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your host.

CONTROLS
Input and Output set levels. A, D, F and OPTO select compression characters. Bottom and Top shape tone, with adjacent Pre/Post placement. THD controls harmonic drive; Mix blends dry and processed sound. SC 85 filters the detector. PWR bypasses processing while retaining the selected oversampling delay.

Drag or wheel knobs, use arrow, Home and End keys, hold Shift or Control for fine changes, and double-click a knob face to restore defaults. Double-click a readout or press Return on a focused knob to enter a value; Return commits and Escape cancels. Auto Gain counters Input changes with Output. The OS menu selects Off, 2x, 4x, 8x or 16x; latency is 0, 62, 76, 82 or 84 samples respectively, including bypass. Stereo Link uses a shared detector; off selects dual mono. These three toolbar choices are saved with plugin state.

LICENSE
Complete project and applicable SDK/runtime notices are included in LICENSES/PLUGIN-AND-THIRD-PARTY-NOTICES.md.
