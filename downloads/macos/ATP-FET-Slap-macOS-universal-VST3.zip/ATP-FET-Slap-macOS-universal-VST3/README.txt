FET Slap — v1.1
Mac VST3

INSTALL
Extract this ZIP. Copy the complete ATP FET Slap.vst3 bundle into ~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your host.

CONTROLS
Mix blends dry and processed audio. Tone shapes the driven signal balance. Snap sets transient drive from 0 to 30 dB; Output sets gain from -15 to +15 dB. Drag the knobs, use the wheel or arrow keys, hold Shift or Control for fine changes, and double-click to restore defaults.

2x OS enables oversampling. Effect Active is the original internal bypass: off returns immediate dry audio. The host bypass also returns immediate dry audio. Oversampling has 64 samples of effective latency only while the effect is active and host bypass is off; hosts are notified when that changes.

LICENSE
Complete project and applicable SDK/runtime notices are included in LICENSES/PLUGIN-AND-THIRD-PARTY-NOTICES.md.
