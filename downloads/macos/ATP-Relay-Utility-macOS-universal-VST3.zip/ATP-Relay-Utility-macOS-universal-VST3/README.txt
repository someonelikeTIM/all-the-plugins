Relay Utility — v1.0
Inspired by Relay, with an independent stereo utility implementation.

Insert ATP Relay Utility on a stereo track.

Output: -60 to +10 dB. Pan: left to right, centered by default.
Width: mono through unchanged stereo to widened stereo.
Left / Right delay: 0 to 100 ms. High-pass cutoff: 20 to 120 Hz.
Switches: sum to mono, swap channels, invert polarity, high-pass enabled.
High-pass slope: select 12, 24 or 48 dB/octave.
Bypass: smoothly blends the processing stages toward their bypass state.

Drag or scroll the rotaries; hold Shift or Control for fine adjustment.
Double-click to reset. Arrow keys adjust the selected control.
Click switches and slope choices directly.

INSTALL
Close your audio host. Extract the ZIP and copy the complete plugin bundle
to the destination below, then reopen your host and use its normal scan.
Keep the bundle contents together.

Bundle: ATP Relay Utility.vst3
Destination: ~/Library/Audio/Plug-Ins/VST3/

LICENSE
Full plugin and dependency terms are in LICENSES.
