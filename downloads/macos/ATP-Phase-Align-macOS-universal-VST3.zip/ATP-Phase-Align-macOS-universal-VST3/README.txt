Phase Align — v1.1
Independent delay and all-pass alignment utility inspired by X-Phase.

Copy the complete ATP Phase Align.vst3 bundle to:
~/Library/Audio/Plug-Ins/VST3/
Reopen your host and use its normal plugin scan.

Select LEFT or RIGHT to edit that channel. Drag knobs, use Shift or Control
for fine adjustment, and double-click to reset. Wheel and arrow keys adjust
the focused knob. Inner curved delay fields make fine changes; outer fields
make coarse changes. The unit menu changes the readout, not the saved delay
precision. LINK applies relative UI edits to both channels; host automation
remains independent. Switches enable delay, all-pass, inversion and order.
Use the host bypass control. Mono uses the left processing controls.

The side meters show actual input/output levels; LAST marks stopped audio.
The phase graph shows the target all-pass response at the current sample rate.

Full plugin and dependency license terms are in LICENSES.
