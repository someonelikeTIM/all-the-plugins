Demon Lock XL — Mac VST3 v1.1

Install
Extract the ZIP and copy the complete ATP Demon Lock XL.vst3 bundle into
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
Replace an existing copy of this same plugin rather than keeping duplicate copies.

Controls
Crush and Crunch: 0.0 to 10.0. Mix: 0 to 100%.
Darkness: 20000 down to 500 Hz. Release: Slow or Fast.
Drag or wheel the four knobs to adjust; double-click resets their defaults.
Click Release to choose Slow or Fast.
Defaults: Crush 1.0, Crunch 1.0, Mix 100%, Darkness 20000 Hz, Slow release.
The host's Bypass control retains latency-aligned dry audio. The editor has no
separate bypass button.

Processing
32-bit floating-point mono and stereo at 44.1, 48, 88.2, 96, 176.4 and 192 kHz.
Reported latency: 63 samples at 44.1/48 kHz, 111 at 88.2/96 kHz, and 205 at
176.4/192 kHz. Dry Mix and host Bypass retain the corresponding alignment.
The plugin's identifiers and existing saved-state format remain compatible.

License
Full project and applicable third-party notices are included in LICENSES/.
