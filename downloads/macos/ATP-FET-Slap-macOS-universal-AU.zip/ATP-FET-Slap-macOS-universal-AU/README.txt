FET Slap — v1.1
Mac Audio Unit

INSTALL
Extract this ZIP. Copy the complete ATP FET Slap.component bundle into ~/Library/Audio/Plug-Ins/Components/, then reopen and rescan your host. Keep the component contents together.

CONTROLS
Mix blends dry and processed audio. Tone shapes the driven signal balance. Snap sets transient drive from 0 to 30 dB; Output sets gain from -15 to +15 dB. Drag the knobs, use the wheel or arrow keys, hold Shift for fine changes, and double-click to restore defaults.

2x OS enables oversampling. Effect Active is the original internal bypass: off returns immediate dry audio. Host bypass also returns immediate dry audio. Oversampling has 64 samples of effective latency only while the effect is active and host bypass is off; hosts are notified when that changes.

LICENSE
Complete project and SDK/runtime notices are in LICENSES/PLUGIN-AND-THIRD-PARTY-NOTICES.md. The AU wrapper's Apple AudioUnitSDK license is included in full as LICENSES/Apple-AudioUnitSDK-Apache-2.0.txt.
