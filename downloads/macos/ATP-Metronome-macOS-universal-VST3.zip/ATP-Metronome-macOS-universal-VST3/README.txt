Metronome — v1.0
Inspired by standalone Metronome, with independently synthesized clicks.

Load ATP Metronome as an instrument or generator and route its stereo output
to an audio bus. It follows host tempo and meter.

Volume: drag or scroll the rotary, double-click to reset to 50%; hold Shift
or Control for fine adjustment. Arrow keys also adjust the selected control.
Accent: use a brighter, louder click on the first beat of the bar.
Play mode: Playback runs during playback or recording; Count-in runs when
the host indicates recording while playback is stopped; Always also runs
while the transport is stopped.
Bypass: fade the click to silence.

INSTALL
Close your audio host. Extract the ZIP and copy the complete plugin bundle
to the destination below, then reopen your host and use its normal scan.
Keep the bundle contents together.

Bundle: ATP Metronome.vst3
Destination: ~/Library/Audio/Plug-Ins/VST3/

LICENSE
Full plugin and dependency terms are in LICENSES.
