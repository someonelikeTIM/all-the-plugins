ATP Stereo Loner 0.1.0

Stereo utility with L/R swap, exclusive Left/Right/Mid/Side solo, stepped
width control, and bypass. Use the custom editor or your host automation.
Width: drag up/down, hold Shift for fine adjustment, double-click for 100%,
or use arrow keys / mouse wheel. Solo buttons are mutually exclusive.

macOS 12 or later. Universal Apple silicon / Intel binary.
Requires a 64-bit audio host supporting the included plugin format.

INSTALL
Close your audio host before copying the complete plugin bundle. In Finder,
choose Go > Go to Folder and enter the destination below. Create the final
format folder if needed, then copy the plugin bundle into it. Reopen your
host and use its normal plugin scan. Keep the bundle's contents together.

Format: VST3
Bundle: ATP Stereo Loner.vst3
Destination: ~/Library/Audio/Plug-Ins/VST3/

LICENSE
Full plugin and dependency licenses are included in LICENSES.
