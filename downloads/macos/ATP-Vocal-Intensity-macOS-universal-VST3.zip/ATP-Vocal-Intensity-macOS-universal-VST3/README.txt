Vocal Intensity — Mac VST3 v1.1

Install
Extract the ZIP and copy the complete ATP Vocal Intensity.vst3 bundle into
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
Replace an existing copy of this same plugin rather than keeping duplicate copies.

Controls
Intensity adjusts the existing leveler amount from -24 to +24 dB. HP Freq and
LP Freq set the high-pass and low-pass positions; the editor displays their
nominal frequencies. Bump changes the high-pass resonance. Bright enables
the existing bright filter stage. Drag or wheel the three rotaries to adjust;
Shift gives fine adjustment. Double-click or right-click a rotary to reset it.
Tab moves focus; arrow keys adjust a focused rotary, and Home/End set extrema.

Hold Compare to audition the existing comparison path. Release, Escape or
focus loss restores the exact previous normalized comparison setting. Host
Bypass remains available without a redundant editor bypass button.

RTA IN switches the spectra display for this editor only; it changes neither
processing nor saved state. The two spectra observe the leveler output and the
filter output before the final limiter. The output meter shows actual RMS over
the measured 2048-sample window with the face calibration 0 = -12 dBFS RMS.
Leveler reduction and LIMIT show actual applied gain reductions. Held/no-data
indicators describe the latest available observation, not an invented live value.

Processing
32-bit floating-point mono and stereo, with zero reported latency. Plugin and
parameter identifiers and saved-state compatibility remain unchanged.

License
Full project and applicable third-party notices are included in LICENSES/.
