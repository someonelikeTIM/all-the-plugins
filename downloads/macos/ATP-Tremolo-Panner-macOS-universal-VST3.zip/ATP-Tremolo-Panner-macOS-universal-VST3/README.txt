Tremolo Panner — Mac VST3 v1.1

Install
Extract the ZIP and copy the complete ATP Tremolo Panner.vst3 bundle into
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
Replace the existing copy of this same plugin rather than keeping duplicates.

Controls
Mix blends the dry and modulated signals. Filter chooses the affected frequency
region. The seven LFO shapes include Swell, Sine, Triangle, Tri-Saw, Swells,
Linear and Gated. LFO Bias changes the modulation shape; Phase shifts its cycle.
Beat Division selects the rhythmic period. Steps sets 6–16 editable points for
the custom shapes; drag the graph handles to shape the pattern.

Sync selects Free Run, Host Tempo or Playhead. BPM sets the internal rate from
40 to 208 BPM. Stereo Offset adjusts the stereo modulation offset. The graph displays
the current modulation curve; its phase marker follows actual processing.
The phase-marker visibility control affects this editor only.

Drag the rotaries and sliders, or wheel to step their values. Hold Shift while
dragging a rotary or using arrow keys for fine adjustment.
Double-click a rotary to restore its default. Hold Compare to audition its
comparison path; release, Escape or focus loss restores the previous setting.
Host Bypass remains available without a redundant editor bypass control.

Processing
32-bit floating-point mono and stereo, with zero reported latency. Existing
plugin identifiers, parameters and saved-state compatibility are preserved.

License
Full project and applicable third-party notices are included in LICENSES/.
