Tube Hearth — v1.1
Mac VST3

INSTALL
Extract this ZIP. Copy the complete ATP Tube Hearth.vst3 bundle into ~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your host.

CONTROLS
Bass and Treble shape tone. Input and Output adjust level and saturation character. Mix blends the latency-aligned dry and processed sound. Mic/Line selects character; Noise enables circuit-style noise. The Heat meter shows internal signal intensity through the saturation path.

Drag the five knobs or use the wheel and arrow keys. Hold Shift for fine changes. Double-click a knob face or press Return on a focused knob to restore its default; Home and End select the range endpoints. Use Space on a focused switch to toggle it. Use the host bypass control; there is no separate editor bypass button.

LICENSE
Complete project and applicable SDK/runtime notices are included in LICENSES/PLUGIN-AND-THIRD-PARTY-NOTICES.md.
