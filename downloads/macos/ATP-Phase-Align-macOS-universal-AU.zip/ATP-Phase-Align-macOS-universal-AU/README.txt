Phase Align — v1.1
Mac Audio Unit

INSTALL
Extract this ZIP. Copy the complete ATP Phase Align.component bundle into ~/Library/Audio/Plug-Ins/Components/, then reopen and rescan your host. Keep the component contents together.

CONTROLS
Select LEFT or RIGHT to edit that channel. Drag knobs, hold Shift for fine adjustment, and double-click to reset. Wheel and arrow keys adjust the focused knob. Inner curved delay fields make fine changes; outer fields make coarse changes. The unit menu changes the readout, not the saved delay precision. LINK applies relative UI edits to both channels; host automation remains independent. Switches enable delay, all-pass, inversion and order. Use the host bypass control. Mono uses the left processing controls.

The side meters show actual input/output levels; LAST marks stopped audio. The phase graph shows the target all-pass response at the current sample rate.

LICENSE
Complete project and SDK/runtime notices are in LICENSES/PLUGIN-AND-THIRD-PARTY-NOTICES.md. The AU wrapper's Apple AudioUnitSDK license is included in full as LICENSES/Apple-AudioUnitSDK-Apache-2.0.txt.
