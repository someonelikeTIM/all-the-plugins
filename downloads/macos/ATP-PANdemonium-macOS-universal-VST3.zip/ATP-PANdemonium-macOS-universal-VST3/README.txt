PANdemonium — v1.1
Mac VST3

INSTALL
Extract this ZIP. Copy the complete ATP PANdemonium.vst3 bundle into ~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your host.

CONTROLS
Motion mode selects LFO, Rhythm Step, Rhythm Shape, Ping Pong, Random or Random Step. Offset, Width and Smoothing shape travel; Mix blends the delayed dry and moving signal. Input and Output set level. Digital/Analog and the eight Character choices select the processing character. The motion display follows the current pan position.

Drag or wheel knobs; use arrow keys, Shift for fine changes, and double-click a knob to reset. Tab selects knobs and Return restores the selected default. Rhythm Step graph clicks add points; drag to move and right-click to remove. Rhythm Shape graph clicks add events; drag to move, Shift-drag to change duration and right-click to remove. Bars, Beats, Grid and curve shape the patterns.

Host uses valid host beat and tempo; without valid musical context it holds rhythmic position. Manual uses Tempo independently of host transport. Trigger works in Ping Pong and Random Step when the left trigger source is below threshold; Divider counts triggers. Threshold, Attack, Release and detector modulation shape response. Trigger filter, cutoff and gain shape the detector; Monitor auditions that filtered left path equally in both output channels. Use the host bypass control; no separate bypass button is present in the editor.

RHYTHM STEP
For Rhythm Step, use 48, 96 or 192 kHz with 64- or 128-sample host buffers. Other buffer lengths and 44.1/88.2/176.4 kHz can shift its short step transitions.

LICENSE
Complete project and applicable SDK/runtime notices are included in LICENSES/PLUGIN-AND-THIRD-PARTY-NOTICES.md.
