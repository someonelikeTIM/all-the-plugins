Redux Axx — Mac VST3 v1.0

Requires macOS 26.0 or newer and a stereo VST3 host. Universal arm64/x86_64.

Install
Extract the ZIP and copy the complete ATP Redux Axx.vst3 bundle to
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
Replace an existing copy of this same plugin rather than keeping duplicates.

Controls
Threshold: Sets the compression threshold from −60 to 0 dB.
Gain: Sets output gain from −30 to 0 dB.
Attack: Sets attack time from 0 to 50 ms.
Input, Output and Attenuation: Display peak levels and processing attenuation from the audio engine.

Defaults: Threshold 0 dB, Gain 0 dB, Attack 5 ms.
Threshold and Gain use vertical sliders; Attack uses the horizontal slider.
Drag sliders to adjust. Tab moves keyboard focus; arrow keys adjust the focused
control. Host bypass remains available through the audio host.

Processing
Stereo 32-bit and 64-bit floating-point processing. Lookahead latency is
64, 128 or 256 samples according to sample rate; reported tail equals that delay.
Existing parameter identifiers and saved projects retain their original behavior.

License
Full project and applicable third-party notices are included in LICENSES/.
