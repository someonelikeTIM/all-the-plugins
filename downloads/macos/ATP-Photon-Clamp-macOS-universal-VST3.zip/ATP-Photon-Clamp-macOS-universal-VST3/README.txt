Photon Clamp — v1.0
Mac VST3

INSTALL
Extract this ZIP. Copy the complete ATP Photon Clamp.vst3 bundle into ~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your host.

CONTROLS
INPUT and OUTPUT adjust the displayed input/output level controls. RATIO selects 2:1, 3:1, 4:1, 10:1 or NUKE (38:1). SAT MODE selects Normal, S1 or S2; click an active S1/S2 button again to return to Normal. THD adjusts harmonic drive; MIX blends dry and processed paths. LOW and HIGH shape tone, with separate PRE/POST placement choices. SC HPF filters the compression detector rather than the audio output.

AUTO GAIN counter-adjusts OUTPUT as INPUT changes, within the output control range. Turning it on sets OUTPUT opposite the current displayed INPUT value. A later explicit OUTPUT edit establishes a new offset. This is linked control compensation, not automatic loudness measurement.

Core IN is separate from host bypass. IN off ramps the wet feed down while a raw dry branch is added after OUTPUT; the wet network continues processing zero input and existing tails. ATTACK and RELEASE adjust continuous 0–10 timing controls; their readouts are not milliseconds. Host bypass remains available through the host.

OVSMP selects Off, 2x, 4x, 8x or 16x. Reported latency is respectively 0, 62, 76, 82 or 84 samples. STEREO/DUAL selects linked or dual-mono compression. AUTO GAIN, OVSMP, both PRE/POST switches, STEREO/DUAL, Core IN and both timing controls are saved with plugin state; these eight settings are not additional host automation parameters.

The GAIN REDUCTION strip shows the detector-driven reduction indication; SATURATION shows a smoothed drive-level indication. These are processing-derived indicators, not output peak meters or calibrated dB readouts.

Drag or wheel a knob; hold Shift while dragging for fine adjustment. Double-click resets to the control default. Click ratio, mode and switch controls directly. Open OVSMP to choose its menu option. Tab traverses the eight additional controls; use arrows for timing controls and the menu, Return/Space to select, and Escape to close the menu.

LICENSE
Complete project and applicable SDK/runtime notices are included in LICENSES/PLUGIN-AND-THIRD-PARTY-NOTICES.md. The pinned SDK's complete MIT text is also supplied separately.
