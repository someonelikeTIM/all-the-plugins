Redux Vox — Mac Audio Unit v1.0

Requires macOS 26.0 or newer and a stereo Audio Unit host. Universal arm64/x86_64.

Install
Extract the ZIP and copy the complete ATP Redux Vox.component bundle to
~/Library/Audio/Plug-Ins/Components/, then reopen and rescan your audio host.
Replace an existing copy of this same plugin rather than keeping duplicates.

Controls
Compression: Sets compression from −36 to 0 dB.
Gain: Sets output gain from −36 to 0 dB.
Gate: Sets the gate threshold; the minimum position disables gating.
Input, Output and Attenuation: Display peak levels and processing attenuation from the audio engine.

Defaults: Compression 0 dB, Gain 0 dB, Gate off.
Gate is a vertical slider; Compression and Gain use the other two vertical sliders.
Drag sliders to adjust. Tab moves keyboard focus; arrow keys adjust the focused
control. Host bypass remains available through the audio host.

Processing
Stereo 32-bit floating-point processing. Lookahead latency is
64, 128 or 256 samples according to sample rate; reported tail equals that delay.
Existing parameter identifiers and saved projects retain their original behavior.

License
Full project and applicable third-party notices are included in LICENSES/.

The AU wrapper uses Apple AudioUnitSDK 1.3.0. Its complete Apache 2.0 license is included in LICENSES/Apple-AudioUnitSDK-Apache-2.0.txt.
