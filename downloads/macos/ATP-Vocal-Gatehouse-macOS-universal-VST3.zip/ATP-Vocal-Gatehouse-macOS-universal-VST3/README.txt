Vocal Gatehouse — Mac VST3 v1.1

Install
Extract the ZIP and copy the complete ATP Vocal Gatehouse.vst3 bundle into
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
Replace an existing copy of this same plugin rather than keeping duplicate copies.

Controls
Open sets the gate threshold; Close is an offset below Open for hysteresis.
Drag their labeled handles on the live input-history graph. Attack uses the
existing 100.9^n - 0.9 millisecond law; Release uses 1200^n milliseconds.
Ratio controls expansion strength: its display spans 1:1 to 50:1 and the
processing curve caps the ratio at 30:1. Wet blends the gate action.
Input and Output use vertical gain faders. Pan and Width use horizontal sliders.
The waveform history and input/output meters observe the actual processed blocks.

The three original switches remain functional. Module Bypass bypasses the gate
stage while the other wet-path controls remain active. Global Bypass returns to
the latency-aligned raw path. Match applies level matching to that global bypass
comparison; with Match active, bypass is not an unscaled unity-gain comparison.

Drag or wheel controls to adjust them. Double-click or right-click resets a
control to its default. Keyboard navigation and adjustments target the focused
editor control. Plugin and parameter identifiers and existing projects remain
compatible; the state is the same 108-byte magic-plus-thirteen-doubles format
with no explicit version field. Public v1.1 does not introduce a state version.

Processing
32-bit floating-point mono and stereo. Source setup accepts sample rates from
44.1 through 192 kHz. Reported latency is round(sample_rate * 0.001) - 1 samples:
43/47/87/95/175/191 at 44.1/48/88.2/96/176.4/192 kHz respectively. Both bypass
paths keep the corresponding delay alignment.

License
Full project and applicable third-party notices are included in LICENSES/.
