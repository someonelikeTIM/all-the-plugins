Overtone Mill — Mac VST3 v1.1

Install
Extract the ZIP and copy the complete ATP Overtone Mill.vst3 bundle into
~/Library/Audio/Plug-Ins/VST3/, then reopen and rescan your audio host.
Replace an existing copy of this same plugin rather than keeping duplicate copies.

Controls
Input Gain and Output Gain: -30 to 0 dB.
Drive: -12 to +24 dB. Depth: 0 to 100%. Harmonics: 0 to 100%.
Shape: -50 to +50%. Dry/Wet Mix: 0 to 100%.
IN enables processing; its off state is the existing host bypass control.
+6 dB changes the saturation headroom.
Drag or wheel the knobs to adjust; double-click resets their defaults.
Input/Output default to 0 dB, Drive to 0 dB, Depth/Harmonics/Shape to midpoint,
Mix to 100%, +6 dB off, and IN on.

The side meters show the last processed input and output levels. The center
needle follows the processor's normalized saturation/color indication.
It is not a calibrated THD or gain-reduction meter.

Processing
32-bit floating-point mono and stereo processing; zero reported latency and tail.
The processor retains its existing startup and parameter-transition behavior.
The plugin's identifiers and version-1 saved-state format remain compatible.

License
Full project and applicable third-party notices are included in LICENSES/.
