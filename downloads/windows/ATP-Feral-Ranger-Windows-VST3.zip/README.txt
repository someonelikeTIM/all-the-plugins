ATP Feral Ranger
Windows VST3

Install
1. Extract this ZIP.
2. Copy the whole ATP Feral Ranger.vst3 folder to C:\Program Files\Common Files\VST3.
3. Open your audio host and rescan its plugins.

When updating a previous ATP build, replace its old bundle. Do not keep both builds installed: they share the same VST3 identity.

Full license notices are in LICENSES.txt.
