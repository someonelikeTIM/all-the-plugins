ATP Lookahead Compressor
Windows VST3

Install
1. Extract this ZIP.
2. Copy the whole "ATP Lookahead Compressor.vst3" folder into:
   C:\Program Files\Common Files\VST3
3. Rescan plugins in your audio application.

When updating, replace the previous ATP Lookahead Compressor build.
Do not keep duplicate copies with the same plugin ID.

The complete license notices are in LICENSES.txt.
